package snippet;

public class Snippet {
//	 Which forms are based on the concept of functional dependency:
//	a) 1NF
//	b) 2NF
//	c) 3NF
//	d) 4NF
}

